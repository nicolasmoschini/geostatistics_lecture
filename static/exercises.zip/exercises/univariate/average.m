function m = average(x)
  %  average  Calculate arithmetric mean
  % 
  %  Arguments
  %  ---------
  %  x    1D array of sample input data
  %
  %  Returns
  %  -------
  %  m  double, the mean of x
  %
  
  % REPLACE FROM HERE
  m = mean(x);
  % TO HERE
end
